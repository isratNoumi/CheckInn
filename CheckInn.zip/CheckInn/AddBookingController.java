/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class AddBookingController implements Initializable {

    @FXML
    private TextField guestname;
    @FXML
    private TextField bookno;
    @FXML
    private TextField roomno;
    @FXML
    private TextField indate;
    @FXML
    private TextField outdate;
    @FXML
    private TextField contact;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void registerbtn(ActionEvent event) {
          PreparedStatement pst=null;
        try
        {
            String query="INSERT INTO `booking`(`Booking No`, `Guest Name`, `Room No`, `Check In Date`, `Check Out Date`, `Contact No`) VALUES (?,?,?,?,?,?)";
             Connection con=database.createConnection();
             pst=con.prepareStatement(query);
             
          
            
             pst.setString(1, bookno.getText() );
              pst.setString(2, guestname.getText());
               pst.setString(3, roomno.getText());
               pst.setString(4, indate.getText());
                pst.setString(5, outdate.getText());
                pst.setString(6, contact.getText());
               
                 pst.executeUpdate();
                 JOptionPane.showMessageDialog(null, "Record Added Successfully!");
                 
        }catch(Exception e){
            
        }
    }

    @FXML
    private void returnbtn(ActionEvent event) {
    }

    @FXML
    private void clearbtn(ActionEvent event) {
           guestname.setText(" ");
        bookno.setText(" ");
        roomno.setText(" ");
        indate.setText(" ");
        outdate.setText(" ");
        contact.setText(" ");
        
    }
    
}

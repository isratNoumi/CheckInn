/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class CHECKINController implements Initializable {

    @FXML
    private TableView<modeltable2> table2;
    @FXML
    private TableColumn<modeltable2,String> col_book;
    @FXML
    private TableColumn<modeltable2, String> col_gname;
    @FXML
    private TableColumn<modeltable2, String> col_room;
    @FXML
    private TableColumn<modeltable2, String> col_in;
    @FXML
    private TableColumn<modeltable2, String> col_out;
    @FXML
    private TableColumn<modeltable2, String> col_contact;
    ObservableList<modeltable2> oblist1= FXCollections.observableArrayList();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         col_book.setCellValueFactory(new PropertyValueFactory<> ("BookingNo"));
         col_gname.setCellValueFactory(new PropertyValueFactory<> ("GuestName"));
          col_room.setCellValueFactory(new PropertyValueFactory<> ("RoomNo"));
          col_in.setCellValueFactory(new PropertyValueFactory<> ("CheckInDate"));
          col_out.setCellValueFactory(new PropertyValueFactory<> ("CheckOutDate"));
          col_contact.setCellValueFactory(new PropertyValueFactory<> ("ContactNo"));
              
                
        try {
          Connection con=database.createConnection();
            ResultSet rs=con.createStatement().executeQuery("select * from booking ");
            while(rs.next())
            {
                oblist1.add(new modeltable2(rs.getString("Booking No"),rs.getString("Guest Name"),rs.getString("Room No"),rs.getString("Check In Date"),rs.getString("Check Out Date"),rs.getString("Contact No")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeesController.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        table2.setItems(oblist1);
          
        // TODO
    }  
     
         
   
   
    
    
      
                 
    @FXML
    private void AddBooking(ActionEvent event) throws IOException {
  Parent root4=FXMLLoader.load(getClass().getResource("AddBooking.fxml"));
        Scene scene4 = new Scene(root4);
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene4);
        window.show();
    }
    
}

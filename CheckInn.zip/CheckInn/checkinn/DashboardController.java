/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

import java.awt.Label;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class DashboardController implements Initializable {

    @FXML
    private Label label;
    public TextField countUser;
     public TextField countGuest;
    public BorderPane mainpane;

    /**
     * Initializes the controller class.
     */
     public void handlecheckinbtnAction(ActionEvent event)
        {
            
            System.out.println("You clicked me");
            Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("CHECKIN");
            mainpane.setCenter(view);
            
        }
      public void employeebtn(ActionEvent event)
        {
            
            System.out.println("You clicked me");
            Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("Employees");
            mainpane.setCenter(view);
        
            
        }
       public void roombtn(ActionEvent event)
        {
            
            System.out.println("You clicked me");
             Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("Rooms");
            mainpane.setCenter(view);
          
            
        }
        public void foodbtn(ActionEvent event)
        {
            
            System.out.println("You clicked me");
             Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("FoodItems");
            mainpane.setCenter(view);
         
            
        }
         public void guestbtn(ActionEvent event)
        {
            
            System.out.println("You clicked me");
              Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("GuestList");
            mainpane.setCenter(view);
           
            
        }
          public void checkoutbtn(ActionEvent event)
        {
            
            System.out.println("You clicked me");
              Fxmlloader object=new Fxmlloader();
            Pane view=object.getPage("Checkout");
            mainpane.setCenter(view);
           
           
            
        }
          public void user()
          {
        try {
            Connection con=database.createConnection();
                   PreparedStatement pst=null;
                   
                  
                      
                   pst=con.prepareStatement("SELECT COUNT(*)  FROM member");
                   ResultSet  rs=pst.executeQuery();
                   while(rs.next())
                   {
                     int sum=rs.getInt(1);
                       countUser.setText(String.valueOf(sum));
                   }
                   
                   

        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
            public void guest()
          {
        try {
            Connection con=database.createConnection();
                   PreparedStatement pst=null;
                   
                  
                      
                   pst=con.prepareStatement("SELECT COUNT(*)  FROM booking");
                   ResultSet  rs=pst.executeQuery();
                   while(rs.next())
                   {
                     int sum=rs.getInt(1);
                       countGuest.setText(String.valueOf(sum));
                   }
                   
                   

        } catch (SQLException ex) {
            Logger.getLogger(DashboardController.class.getName()).log(Level.SEVERE, null, ex);
        }
          }
          
     

    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        user();
        guest();
      
    }    
    
}

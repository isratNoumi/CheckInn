/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

/**
 *
 * @author HP
 */
public class modeltable {
   String Firstname,Lastname,Department,JobTitle,email, EmployeeId,ContactNo;
    public modeltable(String Firstname, String Lastname,  String Department, String ContactNo, String EmployeeId, String JobTitle, String email) {
        this.Firstname = Firstname;
        this.Lastname = Lastname;
        this.Department = Department;
         this.ContactNo = ContactNo;
         this.EmployeeId = EmployeeId;
        this.JobTitle = JobTitle; 
         this.email = email;
       
    }

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String Firstname) {
        this.Firstname = Firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String Lastname) {
        this.Lastname = Lastname;
    }

  

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String JobTitle) {
        this.JobTitle = JobTitle;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(  String EmployeeId) {
        this.EmployeeId = EmployeeId;
    }

    public  String getContactNo() {
        return ContactNo;
    }

    public void setContact_no( String Contact_no) {
        this.ContactNo = ContactNo;
    }

   
}

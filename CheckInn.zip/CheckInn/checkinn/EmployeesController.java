/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author HP
 */

public  class EmployeesController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML    
    private TableView<modeltable>  table;
  @FXML 
     private TableColumn<modeltable,String > col_FirstName;
   @FXML 
     private TableColumn<modeltable,String> col_LastName;
   
     @FXML 
     private TableColumn<modeltable,String> col_Department;
      @FXML 
     private TableColumn<modeltable,String> col_ContactNo;
       @FXML 
     private TableColumn<modeltable,String> col_EmployeeId;
        @FXML 
      private TableColumn<modeltable,String> col_JobTitle;
         @FXML 
       private TableColumn<modeltable,String>col_Email;
      
         ObservableList<modeltable> oblist= FXCollections.observableArrayList();
         
   
    @Override
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        col_FirstName.setCellValueFactory(new PropertyValueFactory<> ("Firstname"));
         col_LastName.setCellValueFactory(new PropertyValueFactory<> ("Lastname"));
           col_Department.setCellValueFactory(new PropertyValueFactory<> ("Department"));
            col_ContactNo.setCellValueFactory(new PropertyValueFactory<> ("ContactNo"));
             col_JobTitle.setCellValueFactory(new PropertyValueFactory<> ("JobTitle"));
              col_EmployeeId.setCellValueFactory(new PropertyValueFactory<> ("EmployeeId"));
               col_Email.setCellValueFactory(new PropertyValueFactory<> ("Email"));
                
        try {
          Connection con=database.createConnection();
            ResultSet rs=con.createStatement().executeQuery("select * from member ");
            while(rs.next())
            {
                oblist.add(new modeltable(rs.getString("First Name"),rs.getString("Last Name"),rs.getString("Department"),rs.getString("Contact No"),rs.getString("Employee Id"),rs.getString("Job Title"),rs.getString("Email")));
            }
        } catch (SQLException ex) {
            Logger.getLogger(EmployeesController.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        table.setItems(oblist);
          
  
    }
      
                 
    @FXML
 
    private void AddEmployee(ActionEvent event) throws IOException {
        
    {
        Parent root4=FXMLLoader.load(getClass().getResource("addEmployee.fxml"));
        Scene scene4 = new Scene(root4);
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene4);
        window.show();
       
    }
    }
}
    


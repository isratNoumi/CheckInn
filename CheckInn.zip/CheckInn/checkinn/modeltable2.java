/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

/**
 *
 * @author HP
 */
public class modeltable2 {
     String BookingNo,GuestName,RoomNo,CheckInDate,CheckOutDate,ContactNo;

    public modeltable2(String BookingNo, String GuestName, String RoomNo, String CheckInDate, String CheckOutDate, String ContactNo) {
        this.BookingNo = BookingNo;
        this.GuestName = GuestName;
        this.RoomNo = RoomNo;
        this.CheckInDate = CheckInDate;
        this.CheckOutDate = CheckOutDate;
        this.ContactNo = ContactNo;
    }

    public String getBookingNo() {
        return BookingNo;
    }

    public void setBookingNo(String BookingNo) {
        this.BookingNo = BookingNo;
    }

    public String getGuestName() {
        return GuestName;
    }

    public void setGuestName(String GuestName) {
        this.GuestName = GuestName;
    }

    public String getRoomNo() {
        return RoomNo;
    }

    public void setRoomNo(String RoomNo) {
        this.RoomNo = RoomNo;
    }

    public String getCheckInDate() {
        return CheckInDate;
    }

    public void setCheckInDate(String CheckInDate) {
        this.CheckInDate = CheckInDate;
    }

    public String getCheckOutDate() {
        return CheckOutDate;
    }

    public void setCheckOutDate(String CheckOutDate) {
        this.CheckOutDate = CheckOutDate;
    }

    public String getContactNo() {
        return ContactNo;
    }

    public void setContactNo(String ContactNo) {
        this.ContactNo = ContactNo;
    }
     
    
}

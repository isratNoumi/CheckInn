/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkinn;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class LogInFXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
     public void SignUpScreen(ActionEvent event) throws IOException
    {
        Parent root1=FXMLLoader.load(getClass().getResource("signup.fxml"));
        Scene scene1 = new Scene(root1);
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }
       public void dashboardScreen(ActionEvent event) throws IOException
    {
        Parent root2=FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        Scene scene2 = new Scene(root2);
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene2);
        window.show();
       
    }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       
      
    }    
    
}
